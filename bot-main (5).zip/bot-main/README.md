# Whiteout Survival Discord Bot

Whiteout Survival Discord Bot that supports alliance management, event reminders and attendance tracking, gift code redemption, minister appointment planning and more. This bot is free, open source and self-hosted.

**This is the actively maintained and improved version of the original bot that was created and soon abandoned by Reloisback.**

## 🚀 Getting Started

To get started with the bot, head over to the [wiki](https://github.com/whiteout-project/bot/wiki) for instructions and other information.

If you have any issues with the bot, head over to the [common issues](https://github.com/whiteout-project/bot/wiki/Common-Issues) page or join our [discord server](https://discord.gg/apYByj6K2m) for support.
